import {
  Button,
  TableContainer,
  Table,
} from '@mui/material';
import { MyTableProps, TableType } from './Util';
import { useState } from 'react';
import MyTableHead from './MyTableHead';
import MyTableBody from './MyTableBody';

export default function MyTable({ table, tables, setTables }: MyTableProps) {
  const [isEdit, setIsEdit] = useState(false);
  const [addType, setAddType] = useState(false);
  const [currentTable, setCurrentTable] = useState<TableType>();
  const [addCategory, setAddCategory] = useState(false);

  const handleIsEdit = () => {
    const currentT = { ...table };
    setCurrentTable(currentT);
    setIsEdit(!isEdit);
  };
  const handleAddType = () => {
    setAddType(!addType);
  };
  const handleAddCategory = () => {
    setAddCategory(!addCategory);
  };
  const handleSave = () => {
    setIsEdit(!isEdit);
    
  };
  const handleCancel = () => {
    if (table !== undefined) {
      const newTables = tables.map((obj: any) => {
        if (obj.id === table.id) {
          return currentTable;
        } else {
          return obj;
        }
      });
      setTables(newTables);
      setIsEdit(!isEdit);
      console.log(tables)
    }
  };
  return (
    <div className="table-wrapper">
      <div className="table-top">
        <h3>{table.tName}</h3>
        {!isEdit && (
          <Button onClick={handleIsEdit} variant="outlined" color="primary">
            Edit
          </Button>
        )}
        {isEdit && (
          <>
            <Button
              onClick={handleAddCategory}
              variant="outlined"
              color="primary"
            >
              Add Category
            </Button>
            <Button
              onClick={handleAddType}
              variant="outlined"
              color="secondary"
            >
              Add Types
            </Button>
            <Button onClick={handleCancel} variant="outlined" color="warning">
              Cancel
            </Button>
            <Button onClick={handleSave} variant="outlined" color="success">
              Save
            </Button>
          </>
        )}
      </div>

      <TableContainer>
        <Table>
        <MyTableHead
            isEdit={isEdit}
            table={table}
            tables={tables}
            setTables={setTables}
            addType={addType}
            setAddType={setAddType}
          />
          <MyTableBody
            isEdit={isEdit}
            table={table}
            tables={tables}
            setTables={setTables}
            addCategory={addCategory}
            setAddCategory={setAddCategory}
          />
    
          
        </Table>
      </TableContainer>
      
    </div>
  );
}
