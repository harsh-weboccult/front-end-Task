import { TableCell } from '@mui/material'

export default function MyRowCell() {
  return (
    <TableCell>MyRowCell</TableCell>
  )
}
