
export const initialData = [
  {
    id: 0,
    title: 'smit',
    categoryName: 'soni',
    col: ['col1', 'col2', 'col3'],
    sRowId: [0, 3, 5],
    rows: [
      {
        id: 1,
        title: 'venky',
        childRow: [1, 2, 3],
        rdata: ['0', '0', '0'],
      },
      {
        id: 0,
        title: 'nitish',
        childRow: [1, 2, 3],
        rdata: ['0', '0', '0'],
      },
      {
        id: 3,
        title: 'raydu',
        rdata: ['0', '0', '0'],
      },
    ],
  },
  {
    id: 1,
    title: 'abcd',
    categoryName: 'soni',
    col: ['col1', 'col2', 'col3'],
    sRowId: [1, 2, 3],
    rows: [
      {
        id: 1,
        title: 'venky',
        rdata: ['0', '0', '0'],
      },
      {
        id: 0,
        title: 'nitish',
        rdata: ['0', '0', '0'],
      },
      {
        id: 3,
        title: 'raydu',
        rdata: ['0', '0', '0'],
      },
    ],
  },
  {
    id: 2,
    title: 'hey',
    categoryName: 'soni',
    col: ['col1', 'col2', 'col3'],
    sRowId: [0, 1, 2],
    rows: [
      {
        id: 1,
        title: 'venky',
        rdata: ['0', '0', '0'],
      },
      {
        id: 0,
        title: 'nitish',
        rdata: ['0', '0', '0'],
      },
      {
        id: 3,
        title: 'raydu',
        rdata: ['0', '0', '0'],
      },
    ],
  },
];
