import { Dispatch, useState } from 'react';
import {
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
} from '@mui/material';
import { v4 as uuid } from 'uuid';
import '../styles/Form.css';
import { TableType, Transition } from './Util';

export default function Form({
  setTables,
}: {
  setTables: Dispatch<React.SetStateAction<TableType[]>>;
}) {
  const [isCreate, setIsCreate] = useState(false);
  const [tableName, setTableName] = useState<string>('');
  const [categoryName, setCategoryName] = useState<string>('');
  const [typeNames, setTypeNames] = useState<string[]>([]);

  const unique_id = uuid();
  const table_id = unique_id.slice(0, 8);

  const handleIsCreate = () => {
    setIsCreate(!isCreate);
  };

  const handleAddTypeNames = () => {
    setTypeNames([...typeNames, '']);
  };

  const handleResetForm = () => {
    setTableName('');
    setCategoryName('');
    setTypeNames([]);
  };
  const handleCancel = () => {
    handleResetForm();
    handleIsCreate();
  };

  const handleSubmit = (e: { preventDefault: () => void }) => {
    e.preventDefault();
    const formData = {
      id: table_id,
      tName: tableName,
      cName: categoryName,
      col: typeNames,
      tRowId: [],
      rows: [],
    };
    setTables(pd => [...pd, formData]);
    handleCancel();
  };
  return (
    <div className="form-wrapper">
      <Button variant="contained" onClick={handleIsCreate}>
        Create Table
      </Button>
      <Dialog
        onClose={handleIsCreate}
        open={isCreate}
        TransitionComponent={Transition}
        keepMounted
      >
        <DialogTitle>Enter Details To Create A Table</DialogTitle>
        <DialogContent>
          <form onSubmit={handleSubmit}>
            <TextField
              label="Table Name :"
              variant="outlined"
              value={tableName}
              onChange={e => setTableName(e.target.value)}
            />
            <TextField
              label="Category Name :"
              variant="outlined"
              value={categoryName}
              onChange={e => setCategoryName(e.target.value)}
            />
            {typeNames.length > 0 &&
              typeNames.map((t, index) => (
                <TextField
                  key={index}
                  label="Type :"
                  variant="outlined"
                  value={t}
                  onChange={e =>
                    setTypeNames([
                      ...typeNames.slice(0, index),
                      e.target.value,
                      ...typeNames.slice(index + 1),
                    ])
                  }
                />
              ))}
            <div className="form-btn">
              <Button
                onClick={handleAddTypeNames}
                variant="outlined"
                color="primary"
              >
                Add Types
              </Button>
              <Button
                onClick={handleResetForm}
                variant="outlined"
                color="warning"
              >
                Reset
              </Button>

              <Button onClick={handleCancel} variant="outlined" color="error">
                Cancel
              </Button>
              <Button type="submit" variant="outlined" color="success">
                Save
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
