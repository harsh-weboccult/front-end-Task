import { AddCircle, Delete, ExpandMore } from '@mui/icons-material';
import { Dialog, DialogTitle,DialogContent,TextField,Table, TableCell, TableRow, Button, Accordion, AccordionSummary, AccordionDetails, TableBody } from '@mui/material';
import {  RowType, TableType, Transition } from './Util';
import { Dispatch, useState } from 'react';
import {v4 as uuid } from 'uuid';
import MyRowCell from './MyRowCell';

export default function MyTableRow({ row ,tables,table,isEdit,setTables}:{
  row  : RowType,
  isEdit : boolean,
  table: TableType,
  tables: TableType[],
  setTables: Dispatch<React.SetStateAction<TableType[]>>;

}) {
  const unique_id = uuid();
  const row_id = unique_id.slice(0, 6);
  const [subRowV, setSubRowV] = useState('');
  const [addSubRow,setAddSubRow] = useState(false);

  const  handleCancelSubRow = () => {
    setAddSubRow(!addSubRow);
    setSubRowV('');
  }
  const  handleSaveSubRow = () => {
    const newSRow = {
      id:row_id,
      title:subRowV,
      rData:[],
      childRow:[]
    }
    const newCRowId = [...row.childRow,newSRow.id];

    if(table.rows !== undefined){
      const newRows = table.rows.map((r)=>{
        if(r.id === row.id){
          return{...r,childRow:newCRowId}
        }
        else{
          return {...r};
        }
      })
      const updatedRows = [...newRows,newSRow];

      const newTables = tables.map((obj)=>{
        if(obj.id === table.id){
          return{...obj,rows : updatedRows};
        }
        else{
          return {...obj}
        }
      })
      setTables(newTables);
    }
    console.log(tables)
    handleCancelSubRow();
  }

    return (
    <>
    {row.childRow.length===0 && ( 
    <TableRow key={row.id}>
        <TableCell>
          {isEdit && <Delete color="error" />}
          {row.title}
          {isEdit && <AddCircle onClick={()=> setAddSubRow(!addSubRow)}/>}
        </TableCell>
        {table.col.map((index)=>(
          <MyRowCell/>
        ))}
      </TableRow>
    )
    }
    {row.childRow.length>0 &&(
      <TableRow>
        <TableCell colSpan={table.tName.length}>
          <Accordion>
            <AccordionSummary
            expandIcon = {<ExpandMore/>}
            >
            <p>{isEdit && <Delete color="error" />}
            {row.title}({row.childRow.length})
            {isEdit && <AddCircle onClick={()=> setAddSubRow(!addSubRow)}/>}
            </p>
            </AccordionSummary>
            <AccordionDetails>
            {table.rows.map((r)=>{
          if(row.childRow.includes(r.id)){
            return <>
            <Table>
              <TableBody>
              <MyTableRow
             key={row_id}
             row={r}
             isEdit = {isEdit}
             table={table}
             tables={tables}
             setTables={setTables}
             />
              </TableBody>
             </Table>
            </>
          }
          else{
            return <></>
          }
        })}

            </AccordionDetails>
          </Accordion>
        
       

        </TableCell>
        

      </TableRow>
      
    )}
    
     
      <Dialog open={addSubRow} TransitionComponent={Transition} keepMounted>
        <DialogTitle>Sub Category Name</DialogTitle>
        <DialogContent>
          <TextField
            id="addCategory"
            label="Category"
            variant="outlined"
            size="small"
            margin="dense"
            value={subRowV}
            onChange={e => setSubRowV(e.target.value)}
          />
          <Button
            color="warning"
            variant="outlined"
            onClick={handleCancelSubRow}
          >
            Cancel
          </Button>
          <Button
            color="success"
            variant="outlined"
            onClick={handleSaveSubRow}
          >
            Save
          </Button>
        </DialogContent>
      </Dialog>
    </>
  );
}
