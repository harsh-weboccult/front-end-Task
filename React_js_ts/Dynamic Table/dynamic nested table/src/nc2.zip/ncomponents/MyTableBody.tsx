import {
  TableBody,
  Dialog,
  DialogTitle,
  DialogContent,
  Button,
  TextField,
} from '@mui/material';
import { useState } from 'react';
import { v4 as uuid } from 'uuid';
import { TableBodyPropsType, TableType, Transition } from './Util';
import MyTableRow from './MyTableRow';

export default function MyTableBody({
  table,
  tables,
  isEdit,
  setTables,
  addCategory,
  setAddCategory,
}: TableBodyPropsType) {
  const [crValue, setCrValue] = useState<string>('');
  const unique_id = uuid();
  const row_id = unique_id.slice(0, 6);

  const handleCancelCategory = () => {
    setCrValue('');
    setAddCategory(!addCategory);
  };

  const handleSaveCategory = () => {
    const newRow = {
      id: row_id,
      title: crValue,
      rData: [],
      childRow: [],
    };
    const newTRowId = [...table.tRowId, newRow.id];

    const newRows = [...table.rows, newRow];
    if (table !== undefined) {
      const newTables = tables.map((obj: TableType) => {
        if (obj.id === table.id) {
          return { ...obj, tRowId: newTRowId, rows: newRows };
        } else {
          return {...obj};
        }
      });
      setTables(newTables);
    }
    handleCancelCategory();
  };

  return (
    <>
      <TableBody>
        {table.rows.length > 0 &&
          table.rows.map(row => (
            (table.tRowId.includes(row.id) && <MyTableRow
             key={row.id} 
             row ={row}
             isEdit={isEdit}
              table = {table}
              tables = {tables}
              setTables = {setTables}
              />
            )
            
          ))}
      </TableBody>
      <Dialog open={addCategory} TransitionComponent={Transition} keepMounted>
        <DialogTitle>Category Name</DialogTitle>
        <DialogContent>
          <TextField
            id="addCategory"
            label="Category"
            variant="outlined"
            size="small"
            margin="dense"
            value={crValue}
            onChange={e => setCrValue(e.target.value)}
          />
          <Button
            color="warning"
            variant="outlined"
            onClick={handleCancelCategory}
          >
            Cancel
          </Button>
          <Button
            color="success"
            variant="outlined"
            onClick={handleSaveCategory}
          >
            Save
          </Button>
        </DialogContent>
      </Dialog>
    </>
  );
}
