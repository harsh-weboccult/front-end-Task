import { Slide } from "@mui/material";
import { TransitionProps } from "@mui/material/transitions";
import React, { Dispatch } from "react";

export interface TableType{
    id : string;
    tName : string;
    cName : string;
    col : string[];
    tRowId : string[];
    rows :RowType[]
}
export interface RowType{
    id : string;
    title: string;
    rData : number[];
    childRow : string[]
}
export interface MyTableProps {
  table: TableType;
  tables: TableType[];
  setTables: Dispatch<React.SetStateAction<TableType[]>>;
}
export interface  MyTableHeadProps extends MyTableProps{
  isEdit: boolean;
  addType: boolean;
  setAddType: Dispatch<React.SetStateAction<boolean>>;
}
export interface TableBodyPropsType extends MyTableProps {
  isEdit: boolean;
  addCategory: boolean;
  setAddCategory: Dispatch<React.SetStateAction<boolean>>;
}


export const Transition = React.forwardRef(function Transition(
    props: TransitionProps & {
      children: React.ReactElement<any, any>;
    },
    ref: React.Ref<unknown>
  ) {
    return <Slide direction="up" ref={ref} {...props} />;
  });