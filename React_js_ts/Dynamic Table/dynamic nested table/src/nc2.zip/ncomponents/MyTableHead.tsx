import {
  TableHead,
  TableRow,
  TableCell,
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  Button,
} from '@mui/material';
import React, { useState } from 'react';
import { MyTableHeadProps, Transition } from './Util';
import { Delete } from '@mui/icons-material';

export default function MyTableHead({
  table,
  addType,
  tables,
  isEdit,
  setTables,
  setAddType,
}: MyTableHeadProps) {
  const [typeV, setTypeV] = useState('');

  const handleCancelType = () => {
    setTypeV('');
    setAddType(!addType);
  };

  const handleAddType = () => {
    const newType = [...table.col, typeV];
    console.log(tables);
    if (table !== undefined) {
      const newTables = tables.map((obj: any) => {
        if (obj.id === table.id) {
          return { ...obj, col: newType };
        } else {
          return obj;
        }
      });
      setTables(newTables);
    }
    handleCancelType();
  };

  return (
    <>
      <TableHead>
        <TableRow>
          <TableCell>{table.cName}</TableCell>
          {table.col.length > 0 &&
            table.col.map((c, index) => <TableCell key={index}>{c} {isEdit && <Delete color="error" />}</TableCell>)}
        </TableRow>
      </TableHead>
      <Dialog open={addType} TransitionComponent={Transition} keepMounted>
        <DialogTitle>Type Name</DialogTitle>
        <DialogContent>
          <TextField
            id="addType"
            label="Type"
            variant="outlined"
            size="small"
            margin="dense"
            value={typeV}
            onChange={e => setTypeV(e.target.value)}
          />
          <Button color="warning" variant="outlined" onClick={handleCancelType}>
            Cancel
          </Button>
          <Button color="success" variant="outlined" onClick={handleAddType}>
            Save
          </Button>
        </DialogContent>
      </Dialog>
    </>
  );
}
